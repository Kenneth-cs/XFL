-- 创建数据库
CREATE DATABASE IF NOT EXISTS `xingfuli` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `xingfuli`;

-- 设置时区
SET time_zone = '+08:00';

