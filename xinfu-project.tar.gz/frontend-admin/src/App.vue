<template>
  <router-view />
</template>

<style>
#app {
  height: 100vh;
}
</style>
