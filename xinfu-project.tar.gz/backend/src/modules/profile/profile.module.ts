import { Module } from '@nestjs/common';

/**
 * 用户档案模块
 * 主要功能在UserModule中实现，这里预留用于后续扩展
 */
@Module({})
export class ProfileModule {}

